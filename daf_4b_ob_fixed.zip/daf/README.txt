DoS Attack Fix
Version: 4b for Orangebox games
Date: 4/15/11
Creator: Drunken F00l, www.sourceop.com

This plugin blocks the denial of service attacks released into the wild recently.

Console commands:
daf_status
 - Returns the status of the DoS Attack Fix plugin and prints the IP address of any blocked offenders
daf_reset
 - Resets the banned IP list

CVARs:
daf_version
 - The version of the DoS Attack Fix plugin
daf_enable
 - Enables the DoS Attack Fix plugin (defaults to on)
daf_log
 - Enables logging of new attackers to file (defaults to off; saves to addons/daf/log.txt)
daf_block_alla2cprint
 - Enables blocking of all A2C_PRINT packets (defaults to off)
daf_block_a2cprint_spam
 - Enables blocking of high volumes of A2C_PRINT packets (defaults to on)
daf_block_a2cprint_nonprintable
 - Enables blocking of A2C_PRINT packets with strange characters (defaults to on)
